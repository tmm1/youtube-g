require 'rubygems'
require 'test/unit'
require 'pp'
require File.dirname(__FILE__) + '/../lib/youtube_g'

YouTubeG.logger.level = Logger::ERROR