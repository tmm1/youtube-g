class YouTubeG
  VERSION = '0.5.1'
end